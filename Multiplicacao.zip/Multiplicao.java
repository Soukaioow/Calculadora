
public class Multiplicao extends Operacao {

		public float calcula () {
			
			return Numero1 * Numero2;
			}
		public float calcula(int prm1, int prm2) {
			
		    return prm1 * prm2;
			
			
		}
		
		
	}


