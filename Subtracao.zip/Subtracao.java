
public class Subtracao extends Operacao {

 public float subtracao () {
			
			return Numero1-Numero2;
		 }
		
		public float calcula(int prm1, int prm2) {
			
			  return prm1 - prm2;
			
			
			
		}
	}

