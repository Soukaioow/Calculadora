
public class Potencia extends Operacao{
 
	public float calcula (){
			
		double resultado = 1;
			    for (int i = 0; i < Numero1; i++) {
			        resultado *= i;	
			
		}
			    return (float) resultado;
		
		
	}
		
		
	}


