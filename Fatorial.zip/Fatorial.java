
public class Fatorial extends Operacao {
 
	public float calcula () {
			int resultado = 1;
		    for (int i = 2; i <= Numero1; i++) {
		        resultado *= i;
			}
		    return resultado;
	}
	}	

