
public class Divisao extends Operacao {

	public float calcula () {
			
			return Numero1 / Numero2;
			}
		
		public float calcula (int pmr1, int prm2) {
			
			return pmr1/prm2;
			
			
		}

	}


